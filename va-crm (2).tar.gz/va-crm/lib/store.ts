import { AppState, Company, Contact, Activity, Task, ContentItem, FunnelMetrics } from './types';
import { SEED_DATA } from './seed-data';

const STORAGE_KEY = 'va-crm-data';

export function loadState(): AppState {
  if (typeof window === 'undefined') return SEED_DATA;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveState(SEED_DATA);
      return SEED_DATA;
    }
    return JSON.parse(raw) as AppState;
  } catch {
    return SEED_DATA;
  }
}

export function saveState(state: AppState): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function resetState(): AppState {
  saveState(SEED_DATA);
  return SEED_DATA;
}

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

// ── Company CRUD ──
export function addCompany(state: AppState, company: Omit<Company, 'id' | 'createdAt' | 'updatedAt'>): AppState {
  const now = new Date().toISOString().slice(0, 10);
  const next = { ...state, companies: [...state.companies, { ...company, id: uid(), createdAt: now, updatedAt: now }] };
  saveState(next);
  return next;
}

export function updateCompany(state: AppState, id: string, updates: Partial<Company>): AppState {
  const next = { ...state, companies: state.companies.map(c => c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString().slice(0, 10) } : c) };
  saveState(next);
  return next;
}

export function deleteCompany(state: AppState, id: string): AppState {
  const next = { ...state, companies: state.companies.filter(c => c.id !== id), contacts: state.contacts.filter(c => c.companyId !== id) };
  saveState(next);
  return next;
}

// ── Contact CRUD ──
export function addContact(state: AppState, contact: Omit<Contact, 'id' | 'createdAt'>): AppState {
  const next = { ...state, contacts: [...state.contacts, { ...contact, id: uid(), createdAt: new Date().toISOString().slice(0, 10) }] };
  saveState(next);
  return next;
}

export function updateContact(state: AppState, id: string, updates: Partial<Contact>): AppState {
  const next = { ...state, contacts: state.contacts.map(c => c.id === id ? { ...c, ...updates } : c) };
  saveState(next);
  return next;
}

export function deleteContact(state: AppState, id: string): AppState {
  const next = { ...state, contacts: state.contacts.filter(c => c.id !== id) };
  saveState(next);
  return next;
}

// ── Activity CRUD ──
export function addActivity(state: AppState, activity: Omit<Activity, 'id'>): AppState {
  const next = { ...state, activities: [{ ...activity, id: uid() }, ...state.activities] };
  saveState(next);
  return next;
}

// ── Task CRUD ──
export function addTask(state: AppState, task: Omit<Task, 'id'>): AppState {
  const next = { ...state, tasks: [...state.tasks, { ...task, id: uid() }] };
  saveState(next);
  return next;
}

export function updateTask(state: AppState, id: string, updates: Partial<Task>): AppState {
  const next = { ...state, tasks: state.tasks.map(t => t.id === id ? { ...t, ...updates } : t) };
  saveState(next);
  return next;
}

export function deleteTask(state: AppState, id: string): AppState {
  const next = { ...state, tasks: state.tasks.filter(t => t.id !== id) };
  saveState(next);
  return next;
}

// ── Content CRUD ──
export function updateContent(state: AppState, id: string, updates: Partial<ContentItem>): AppState {
  const next = { ...state, content: state.content.map(c => c.id === id ? { ...c, ...updates } : c) };
  saveState(next);
  return next;
}

export function addContent(state: AppState, item: Omit<ContentItem, 'id'>): AppState {
  const next = { ...state, content: [...state.content, { ...item, id: uid() }] };
  saveState(next);
  return next;
}

// ── Metrics ──
export function updateMetrics(state: AppState, month: string, data: Partial<FunnelMetrics>): AppState {
  const existing = state.metrics.find(m => m.month === month);
  let metrics;
  if (existing) {
    metrics = state.metrics.map(m => m.month === month ? { ...m, ...data } : m);
  } else {
    metrics = [...state.metrics, { month, outreachSent: 0, discoveryCalls: 0, executiveBriefings: 0, proposalsSent: 0, engagementsClosed: 0, revenue: 0, ...data }];
  }
  const next = { ...state, metrics };
  saveState(next);
  return next;
}
