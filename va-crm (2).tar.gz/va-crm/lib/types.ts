export type PipelineStage =
  | 'identified'
  | 'outreach'
  | 'discovery_call'
  | 'executive_briefing'
  | 'proposal'
  | 'assessment'
  | 'retainer'
  | 'closed_won'
  | 'closed_lost';

export const PIPELINE_STAGES: { key: PipelineStage; label: string; color: string }[] = [
  { key: 'identified', label: 'Identified', color: '#94a3b8' },
  { key: 'outreach', label: 'Outreach', color: '#7b93b9' },
  { key: 'discovery_call', label: 'Discovery Call', color: '#2C5F8A' },
  { key: 'executive_briefing', label: 'Exec Briefing', color: '#1B2A4A' },
  { key: 'proposal', label: 'Proposal Sent', color: '#D4A843' },
  { key: 'assessment', label: 'Assessment', color: '#b8912e' },
  { key: 'retainer', label: 'Retainer', color: '#2E7D32' },
  { key: 'closed_won', label: 'Closed Won', color: '#1b5e20' },
  { key: 'closed_lost', label: 'Closed Lost', color: '#c62828' },
];

export type ContactRole = 'champion' | 'economic_buyer' | 'influencer' | 'blocker' | 'other';
export type Tier = '1' | '2' | '3_pe';
export type TaskStatus = 'todo' | 'in_progress' | 'done' | 'blocked';
export type TaskPriority = 'critical' | 'high' | 'medium' | 'low';
export type ContentStatus = 'idea' | 'drafting' | 'ready' | 'published';

export interface Company {
  id: string;
  name: string;
  tier: Tier;
  sector: string;
  painSignal: string;
  entryAngle: string;
  stage: PipelineStage;
  estimatedValue: number;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Contact {
  id: string;
  companyId: string;
  name: string;
  title: string;
  email: string;
  linkedin: string;
  role: ContactRole;
  notes: string;
  lastContactDate: string;
  createdAt: string;
}

export interface Activity {
  id: string;
  companyId?: string;
  contactId?: string;
  type: 'outreach' | 'call' | 'meeting' | 'email' | 'briefing' | 'proposal' | 'note' | 'content';
  description: string;
  date: string;
  outcome?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  phase: string;
  dueDate: string;
  completedDate?: string;
  companyId?: string;
  tags: string[];
}

export interface ContentItem {
  id: string;
  title: string;
  type: 'article' | 'post' | 'carousel' | 'poll' | 'comment_campaign';
  status: ContentStatus;
  week: number;
  topic: string;
  publishDate?: string;
  url?: string;
  engagement?: { reactions: number; comments: number; shares: number };
}

export interface FunnelMetrics {
  month: string;
  outreachSent: number;
  discoveryCalls: number;
  executiveBriefings: number;
  proposalsSent: number;
  engagementsClosed: number;
  revenue: number;
}

export interface AppState {
  companies: Company[];
  contacts: Contact[];
  activities: Activity[];
  tasks: Task[];
  content: ContentItem[];
  metrics: FunnelMetrics[];
}
