'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  AppState, Company, Contact, Activity, Task, ContentItem,
  PipelineStage, PIPELINE_STAGES, TaskStatus, TaskPriority,
  Tier, ContactRole, ContentStatus
} from '@/lib/types';
import {
  loadState, saveState, resetState, uid,
  addCompany, updateCompany, deleteCompany,
  addContact, updateContact, deleteContact,
  addActivity, addTask, updateTask, deleteTask,
  updateContent, addContent
} from '@/lib/store';

// ═══════════════════════════════════════
// ICONS (inline SVG to avoid dependencies)
// ═══════════════════════════════════════
const Icon = ({ d, size = 18, className = '' }: { d: string; size?: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d={d} /></svg>
);

const Icons = {
  dashboard: 'M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 22V12h6v10',
  pipeline: 'M22 12h-4l-3 9L9 3l-3 9H2',
  contacts: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4-4v2 M23 21v-2a4 4 0 00-3-3.87 M9 7a4 4 0 100-8 4 4 0 000 8 M16 3.13a4 4 0 010 7.75',
  tasks: 'M9 11l3 3L22 4 M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11',
  content: 'M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7 M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4 9.5-9.5z',
  activity: 'M12 8v4l3 3 M3 12a9 9 0 1018 0 9 9 0 00-18 0',
  plus: 'M12 5v14 M5 12h14',
  x: 'M18 6L6 18 M6 6l12 12',
  chevDown: 'M6 9l6 6 6-6',
  check: 'M20 6L9 17l-5-5',
  search: 'M11 19a8 8 0 100-16 8 8 0 000 16z M21 21l-4.35-4.35',
  trash: 'M3 6h18 M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2',
  edit: 'M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7 M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4 9.5-9.5z',
  arrowRight: 'M5 12h14 M12 5l7 7-7 7',
  reset: 'M1 4v6h6 M23 20v-6h-6 M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15',
};

type View = 'dashboard' | 'pipeline' | 'contacts' | 'tasks' | 'content' | 'activity';

// ═══════════════════════════════════════
// MODAL COMPONENT
// ═══════════════════════════════════════
function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4" onClick={onClose}>
      <div className="fixed inset-0 bg-black/60" />
      <div className={`relative bg-[var(--bg-card)] border border-[var(--border)] rounded-xl shadow-2xl animate-in ${wide ? 'w-full max-w-2xl' : 'w-full max-w-lg'} max-h-[75vh] overflow-y-auto`} onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-[var(--bg-card)] border-b border-[var(--border)] px-6 py-4 flex items-center justify-between rounded-t-xl z-10">
          <h2 className="text-base font-semibold">{title}</h2>
          <button onClick={onClose} className="text-[var(--text-muted)] hover:text-white transition-colors"><Icon d={Icons.x} /></button>
        </div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
// FORM COMPONENTS
// ═══════════════════════════════════════
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="mb-4"><label className="block text-xs font-medium text-[var(--text-muted)] mb-1.5 uppercase tracking-wider">{label}</label>{children}</div>;
}

function Badge({ text, color = 'gray' }: { text: string; color?: string }) {
  const colors: Record<string, string> = {
    gray: 'bg-gray-800 text-gray-300',
    blue: 'bg-blue-900/50 text-blue-300',
    gold: 'bg-yellow-900/40 text-yellow-300',
    green: 'bg-green-900/40 text-green-300',
    red: 'bg-red-900/40 text-red-300',
    purple: 'bg-purple-900/40 text-purple-300',
    navy: 'bg-[#1B2A4A] text-blue-200',
  };
  return <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider ${colors[color] || colors.gray}`}>{text}</span>;
}

const tierColors: Record<Tier, string> = { '1': 'red', '2': 'gold', '3_pe': 'purple' };
const tierLabels: Record<Tier, string> = { '1': 'Tier 1', '2': 'Tier 2', '3_pe': 'PE Fund' };
const priorityColors: Record<TaskPriority, string> = { critical: 'red', high: 'gold', medium: 'blue', low: 'gray' };
const statusColors: Record<TaskStatus, string> = { todo: 'gray', in_progress: 'blue', done: 'green', blocked: 'red' };
const contentStatusColors: Record<ContentStatus, string> = { idea: 'gray', drafting: 'blue', ready: 'gold', published: 'green' };

// ═══════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════
export default function App() {
  const [state, setState] = useState<AppState | null>(null);
  const [view, setView] = useState<View>('dashboard');
  const [search, setSearch] = useState('');

  // Modal states
  const [showAddCompany, setShowAddCompany] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showAddTask, setShowAddTask] = useState(false);
  const [showAddActivity, setShowAddActivity] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);

  useEffect(() => { setState(loadState()); }, []);

  const s = useCallback((next: AppState) => { setState(next); }, []);

  if (!state) return <div className="flex items-center justify-center h-screen text-[var(--text-muted)]">Loading...</div>;

  const navItems: { key: View; label: string; icon: string }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: Icons.dashboard },
    { key: 'pipeline', label: 'Pipeline', icon: Icons.pipeline },
    { key: 'contacts', label: 'Contacts', icon: Icons.contacts },
    { key: 'tasks', label: 'Tasks', icon: Icons.tasks },
    { key: 'content', label: 'Content', icon: Icons.content },
    { key: 'activity', label: 'Activity', icon: Icons.activity },
  ];

  // ── Stats ──
  const pipelineValue = state.companies.filter(c => !['closed_lost', 'closed_won'].includes(c.stage)).reduce((a, c) => a + c.estimatedValue, 0);
  const activePipeline = state.companies.filter(c => !['closed_lost', 'closed_won', 'identified'].includes(c.stage)).length;
  const tasksDue = state.tasks.filter(t => t.status !== 'done' && t.dueDate <= new Date().toISOString().slice(0, 10)).length;
  const tasksThisWeek = state.tasks.filter(t => {
    if (t.status === 'done') return false;
    const d = new Date(t.dueDate);
    const now = new Date();
    const weekEnd = new Date(now);
    weekEnd.setDate(weekEnd.getDate() + 7);
    return d <= weekEnd;
  }).length;
  const contentReady = state.content.filter(c => c.status === 'ready').length;
  const contentPublished = state.content.filter(c => c.status === 'published').length;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── SIDEBAR ── */}
      <aside className="w-56 shrink-0 bg-[var(--bg-card)] border-r border-[var(--border)] flex flex-col">
        <div className="px-5 py-5 border-b border-[var(--border)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--gold)] to-yellow-700 flex items-center justify-center text-[10px] font-bold text-black">VA</div>
            <div>
              <div className="text-sm font-bold tracking-tight">VA-CRM</div>
              <div className="text-[10px] text-[var(--text-muted)] tracking-wider uppercase">Value Architecture</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 py-3 px-3">
          {navItems.map(item => (
            <button
              key={item.key}
              onClick={() => setView(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm mb-0.5 transition-all ${
                view === item.key
                  ? 'bg-[var(--gold)]/10 text-[var(--gold)] font-medium'
                  : 'text-[var(--text-muted)] hover:text-white hover:bg-[var(--bg-hover)]'
              }`}
            >
              <Icon d={item.icon} size={16} />
              {item.label}
              {item.key === 'tasks' && tasksDue > 0 && (
                <span className="ml-auto text-[10px] bg-red-900/50 text-red-300 px-1.5 py-0.5 rounded-full font-semibold">{tasksDue}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="px-3 pb-4">
          <button onClick={() => { if (confirm('Reset all data to defaults? This cannot be undone.')) { s(resetState()); } }} className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs text-[var(--text-dim)] hover:text-red-400 hover:bg-red-900/10 transition-all">
            <Icon d={Icons.reset} size={13} /> Reset Data
          </button>
        </div>
      </aside>

      {/* ── MAIN CONTENT ── */}
      <main className="flex-1 overflow-y-auto">
        {/* HEADER */}
        <header className="sticky top-0 z-30 glass border-b border-[var(--border)] px-6 py-3 flex items-center justify-between">
          <h1 className="text-lg font-semibold capitalize">{view === 'dashboard' ? 'Dashboard' : view.replace('_', ' ')}</h1>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Icon d={Icons.search} size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-dim)]" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="!pl-8 !py-1.5 !text-xs !w-48" />
            </div>
            <button onClick={() => setShowAddActivity(true)} className="text-xs px-3 py-1.5 bg-[var(--bg-hover)] border border-[var(--border)] rounded-lg hover:border-[var(--gold)] transition-colors flex items-center gap-1.5">
              <Icon d={Icons.activity} size={13} /> Log Activity
            </button>
            <button onClick={() => {
              if (view === 'contacts') setShowAddContact(true);
              else if (view === 'tasks') setShowAddTask(true);
              else setShowAddCompany(true);
            }} className="text-xs px-3 py-1.5 bg-[var(--gold)]/15 text-[var(--gold)] border border-[var(--gold)]/30 rounded-lg hover:bg-[var(--gold)]/25 transition-colors flex items-center gap-1.5">
              <Icon d={Icons.plus} size={13} /> Add {view === 'contacts' ? 'Contact' : view === 'tasks' ? 'Task' : 'Company'}
            </button>
          </div>
        </header>

        <div className="p-6">
          {view === 'dashboard' && <DashboardView state={state} s={s} setView={setView} setEditingCompany={setEditingCompany} setEditingTask={setEditingTask} />}
          {view === 'pipeline' && <PipelineView state={state} s={s} search={search} setEditingCompany={setEditingCompany} />}
          {view === 'contacts' && <ContactsView state={state} s={s} search={search} setShowAddContact={setShowAddContact} setSelectedCompany={setSelectedCompany} />}
          {view === 'tasks' && <TasksView state={state} s={s} search={search} setEditingTask={setEditingTask} />}
          {view === 'content' && <ContentView state={state} s={s} />}
          {view === 'activity' && <ActivityView state={state} s={s} search={search} />}
        </div>
      </main>

      {/* ── MODALS ── */}
      <AddCompanyModal open={showAddCompany || !!editingCompany} onClose={() => { setShowAddCompany(false); setEditingCompany(null); }} state={state} s={s} existing={editingCompany} />
      <AddContactModal open={showAddContact} onClose={() => setShowAddContact(false)} state={state} s={s} preselectedCompany={selectedCompany} />
      <AddTaskModal open={showAddTask || !!editingTask} onClose={() => { setShowAddTask(false); setEditingTask(null); }} state={state} s={s} existing={editingTask} />
      <AddActivityModal open={showAddActivity} onClose={() => setShowAddActivity(false)} state={state} s={s} />
    </div>
  );
}

// ═══════════════════════════════════════
// DASHBOARD VIEW
// ═══════════════════════════════════════
function DashboardView({ state, s, setView, setEditingCompany, setEditingTask }: { state: AppState; s: (n: AppState) => void; setView: (v: View) => void; setEditingCompany: (c: Company) => void; setEditingTask: (t: Task) => void }) {
  const pipelineValue = state.companies.filter(c => !['closed_lost', 'closed_won'].includes(c.stage)).reduce((a, c) => a + c.estimatedValue, 0);
  const activePipeline = state.companies.filter(c => !['closed_lost', 'closed_won', 'identified'].includes(c.stage)).length;
  const tasksDue = state.tasks.filter(t => t.status !== 'done' && t.dueDate <= new Date().toISOString().slice(0, 10));
  const tasksInProgress = state.tasks.filter(t => t.status === 'in_progress');
  const tasksDone = state.tasks.filter(t => t.status === 'done').length;
  const tasksTotal = state.tasks.length;
  const contentPublished = state.content.filter(c => c.status === 'published').length;
  const upcomingTasks = state.tasks.filter(t => t.status !== 'done').sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 8);

  const stageGroups = PIPELINE_STAGES.filter(ps => !['closed_won', 'closed_lost'].includes(ps.key)).map(ps => ({
    ...ps,
    count: state.companies.filter(c => c.stage === ps.key).length,
  }));

  return (
    <div className="space-y-6 animate-in">
      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Pipeline Value" value={`€${(pipelineValue / 1000).toFixed(0)}K`} sub={`${state.companies.length} companies`} accent="gold" />
        <StatCard label="Active Pipeline" value={String(activePipeline)} sub="in active stages" accent="blue" />
        <StatCard label="Tasks Progress" value={`${tasksDone}/${tasksTotal}`} sub={`${tasksDue.length} overdue`} accent={tasksDue.length > 0 ? 'red' : 'green'} />
        <StatCard label="Content Published" value={`${contentPublished}/${state.content.length}`} sub={`${state.content.filter(c => c.status === 'ready').length} ready to go`} accent="purple" />
      </div>

      {/* Pipeline Funnel */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Pipeline Funnel</h3>
          <button onClick={() => setView('pipeline')} className="text-[10px] text-[var(--text-muted)] hover:text-[var(--gold)] transition-colors">View Pipeline →</button>
        </div>
        <div className="flex gap-1 items-end h-28">
          {stageGroups.map(sg => (
            <div key={sg.key} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-lg font-bold" style={{ color: sg.color }}>{sg.count}</span>
              <div className="w-full rounded-t" style={{ backgroundColor: sg.color, height: `${Math.max(8, sg.count * 24)}px`, opacity: sg.count > 0 ? 1 : 0.2, transition: 'height 0.3s' }} />
              <span className="text-[9px] text-[var(--text-dim)] text-center leading-tight mt-1">{sg.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Upcoming Tasks */}
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">Upcoming Tasks</h3>
            <button onClick={() => setView('tasks')} className="text-[10px] text-[var(--text-muted)] hover:text-[var(--gold)] transition-colors">All Tasks →</button>
          </div>
          <div className="space-y-2">
            {upcomingTasks.map(task => (
              <button key={task.id} onClick={() => setEditingTask(task)} className="w-full text-left flex items-start gap-3 px-3 py-2 rounded-lg hover:bg-[var(--bg-hover)] transition-colors group">
                <div className="mt-0.5">
                  <div className={`w-2 h-2 rounded-full ${task.dueDate <= new Date().toISOString().slice(0, 10) && task.status !== 'done' ? 'bg-red-400 animate-pulse' : 'bg-[var(--text-dim)]'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate group-hover:text-[var(--gold)] transition-colors">{task.title}</div>
                  <div className="text-[10px] text-[var(--text-dim)] mt-0.5 flex items-center gap-2">
                    <span>{task.dueDate}</span>
                    <Badge text={task.priority} color={priorityColors[task.priority]} />
                    <Badge text={task.phase.replace('Phase ', 'P').split(':')[0]} color="navy" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">Recent Activity</h3>
            <button onClick={() => setView('activity')} className="text-[10px] text-[var(--text-muted)] hover:text-[var(--gold)] transition-colors">All Activity →</button>
          </div>
          {state.activities.length === 0 ? (
            <div className="text-center py-8 text-[var(--text-dim)] text-xs">No activity logged yet. Start by logging outreach or calls.</div>
          ) : (
            <div className="space-y-2">
              {state.activities.slice(0, 8).map(act => {
                const co = state.companies.find(c => c.id === act.companyId);
                return (
                  <div key={act.id} className="flex items-start gap-3 px-3 py-2">
                    <div className="mt-1 w-1.5 h-1.5 rounded-full bg-[var(--gold)]" />
                    <div className="flex-1">
                      <div className="text-xs">{act.description}</div>
                      <div className="text-[10px] text-[var(--text-dim)] mt-0.5">
                        {co && <span className="text-[var(--text-muted)]">{co.name} · </span>}
                        {act.date} · <span className="capitalize">{act.type}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub, accent }: { label: string; value: string; sub: string; accent: string }) {
  const accentMap: Record<string, string> = {
    gold: 'border-l-[var(--gold)]',
    blue: 'border-l-[var(--blue)]',
    green: 'border-l-green-500',
    red: 'border-l-red-500',
    purple: 'border-l-purple-500',
  };
  return (
    <div className={`bg-[var(--bg-card)] border border-[var(--border)] border-l-2 ${accentMap[accent]} rounded-xl px-5 py-4`}>
      <div className="text-[10px] text-[var(--text-muted)] uppercase tracking-wider mb-1">{label}</div>
      <div className="text-2xl font-bold tracking-tight">{value}</div>
      <div className="text-[11px] text-[var(--text-dim)] mt-0.5">{sub}</div>
    </div>
  );
}

// ═══════════════════════════════════════
// PIPELINE VIEW (Kanban)
// ═══════════════════════════════════════
function PipelineView({ state, s, search, setEditingCompany }: { state: AppState; s: (n: AppState) => void; search: string; setEditingCompany: (c: Company) => void }) {
  const filtered = state.companies.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.sector.toLowerCase().includes(search.toLowerCase())
  );

  const moveStage = (id: string, stage: PipelineStage) => {
    s(updateCompany(state, id, { stage }));
  };

  const activeStages = PIPELINE_STAGES.filter(ps => !['closed_won', 'closed_lost'].includes(ps.key));

  return (
    <div className="animate-in">
      <div className="flex gap-3 overflow-x-auto pb-4">
        {activeStages.map(ps => {
          const cards = filtered.filter(c => c.stage === ps.key);
          return (
            <div key={ps.key} className="kanban-col shrink-0">
              <div className="flex items-center gap-2 mb-3 px-1">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ps.color }} />
                <span className="text-xs font-semibold text-[var(--text-muted)]">{ps.label}</span>
                <span className="text-[10px] text-[var(--text-dim)] ml-auto">{cards.length}</span>
              </div>
              <div className="space-y-2 min-h-[200px]">
                {cards.map(company => (
                  <div key={company.id} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-lg p-3 hover:border-[var(--gold)]/40 transition-all cursor-pointer group" onClick={() => setEditingCompany(company)}>
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-sm font-medium group-hover:text-[var(--gold)] transition-colors">{company.name}</span>
                      <Badge text={tierLabels[company.tier]} color={tierColors[company.tier]} />
                    </div>
                    <div className="text-[10px] text-[var(--text-dim)] mb-2">{company.sector}</div>
                    <div className="text-[10px] text-[var(--text-muted)] line-clamp-2 mb-2">{company.painSignal}</div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-[var(--gold)]">€{(company.estimatedValue / 1000).toFixed(0)}K</span>
                      {ps.key !== 'retainer' && (
                        <select
                          value={company.stage}
                          onChange={e => { e.stopPropagation(); moveStage(company.id, e.target.value as PipelineStage); }}
                          onClick={e => e.stopPropagation()}
                          className="!w-auto !py-0.5 !px-1.5 !text-[10px] !bg-transparent !border-[var(--border)]"
                        >
                          {PIPELINE_STAGES.map(opt => <option key={opt.key} value={opt.key}>{opt.label}</option>)}
                        </select>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {/* Closed deals */}
      <div className="mt-6 grid grid-cols-2 gap-4">
        {['closed_won', 'closed_lost'].map(stage => {
          const ps = PIPELINE_STAGES.find(p => p.key === stage)!;
          const cards = filtered.filter(c => c.stage === stage);
          return (
            <div key={stage} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ps.color }} />
                <span className="text-xs font-semibold text-[var(--text-muted)]">{ps.label}</span>
                <span className="text-[10px] text-[var(--text-dim)] ml-auto">{cards.length}</span>
              </div>
              {cards.length === 0 && <div className="text-[11px] text-[var(--text-dim)] py-2">None yet</div>}
              {cards.map(c => (
                <div key={c.id} className="flex items-center justify-between py-1.5 text-xs">
                  <span className="cursor-pointer hover:text-[var(--gold)]" onClick={() => setEditingCompany(c)}>{c.name}</span>
                  <span className="font-mono text-[var(--text-dim)]">€{(c.estimatedValue / 1000).toFixed(0)}K</span>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
// CONTACTS VIEW
// ═══════════════════════════════════════
function ContactsView({ state, s, search, setShowAddContact, setSelectedCompany }: { state: AppState; s: (n: AppState) => void; search: string; setShowAddContact: (v: boolean) => void; setSelectedCompany: (id: string | null) => void }) {
  const filtered = state.contacts.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.title.toLowerCase().includes(search.toLowerCase())
  );

  const grouped = state.companies.map(co => ({
    company: co,
    contacts: filtered.filter(c => c.companyId === co.id),
  })).filter(g => g.contacts.length > 0 || !search);

  const roleColors: Record<ContactRole, string> = { champion: 'green', economic_buyer: 'gold', influencer: 'blue', blocker: 'red', other: 'gray' };

  return (
    <div className="animate-in space-y-4">
      {grouped.map(g => (
        <div key={g.company.id} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-[var(--border)] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-sm font-semibold">{g.company.name}</span>
              <Badge text={tierLabels[g.company.tier]} color={tierColors[g.company.tier]} />
              <Badge text={PIPELINE_STAGES.find(p => p.key === g.company.stage)?.label || ''} color="navy" />
            </div>
            <button onClick={() => { setSelectedCompany(g.company.id); setShowAddContact(true); }} className="text-[10px] text-[var(--text-muted)] hover:text-[var(--gold)] flex items-center gap-1 transition-colors">
              <Icon d={Icons.plus} size={12} /> Add Contact
            </button>
          </div>
          {g.contacts.length === 0 ? (
            <div className="px-5 py-4 text-xs text-[var(--text-dim)]">No contacts added yet</div>
          ) : (
            <div className="divide-y divide-[var(--border)]">
              {g.contacts.map(contact => (
                <div key={contact.id} className="px-5 py-3 flex items-center gap-4 hover:bg-[var(--bg-hover)] transition-colors">
                  <div className="w-8 h-8 rounded-full bg-[var(--bg)] flex items-center justify-center text-[10px] font-bold text-[var(--text-muted)]">
                    {contact.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium">{contact.name}</div>
                    <div className="text-[11px] text-[var(--text-muted)]">{contact.title}</div>
                  </div>
                  <Badge text={contact.role.replace('_', ' ')} color={roleColors[contact.role]} />
                  {contact.linkedin && (
                    <a href={contact.linkedin} target="_blank" rel="noopener noreferrer" className="text-[10px] text-[var(--text-dim)] hover:text-[var(--gold)] transition-colors">LinkedIn</a>
                  )}
                  <button onClick={() => s(deleteContact(state, contact.id))} className="text-[var(--text-dim)] hover:text-red-400 transition-colors"><Icon d={Icons.trash} size={13} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════
// TASKS VIEW
// ═══════════════════════════════════════
function TasksView({ state, s, search, setEditingTask }: { state: AppState; s: (n: AppState) => void; search: string; setEditingTask: (t: Task) => void }) {
  const [filterPhase, setFilterPhase] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');

  const phases = Array.from(new Set(state.tasks.map(t => t.phase)));

  const filtered = state.tasks.filter(t => {
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) && !t.tags.some(tag => tag.includes(search.toLowerCase()))) return false;
    if (filterPhase !== 'all' && t.phase !== filterPhase) return false;
    if (filterStatus !== 'all' && t.status !== filterStatus) return false;
    if (filterPriority !== 'all' && t.priority !== filterPriority) return false;
    return true;
  }).sort((a, b) => {
    // Sort: overdue first, then by priority, then by date
    const aOverdue = a.status !== 'done' && a.dueDate <= new Date().toISOString().slice(0, 10) ? 0 : 1;
    const bOverdue = b.status !== 'done' && b.dueDate <= new Date().toISOString().slice(0, 10) ? 0 : 1;
    if (aOverdue !== bOverdue) return aOverdue - bOverdue;
    const priOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    if (priOrder[a.priority] !== priOrder[b.priority]) return priOrder[a.priority] - priOrder[b.priority];
    return a.dueDate.localeCompare(b.dueDate);
  });

  const toggleStatus = (task: Task) => {
    const next: TaskStatus = task.status === 'done' ? 'todo' : task.status === 'todo' ? 'in_progress' : task.status === 'in_progress' ? 'done' : 'todo';
    s(updateTask(state, task.id, { status: next, ...(next === 'done' ? { completedDate: new Date().toISOString().slice(0, 10) } : { completedDate: undefined }) }));
  };

  return (
    <div className="animate-in">
      {/* Filters */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <select value={filterPhase} onChange={e => setFilterPhase(e.target.value)} className="!w-auto !text-xs">
          <option value="all">All Phases</option>
          {phases.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="!w-auto !text-xs">
          <option value="all">All Statuses</option>
          <option value="todo">To Do</option>
          <option value="in_progress">In Progress</option>
          <option value="done">Done</option>
          <option value="blocked">Blocked</option>
        </select>
        <select value={filterPriority} onChange={e => setFilterPriority(e.target.value)} className="!w-auto !text-xs">
          <option value="all">All Priorities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <span className="text-[11px] text-[var(--text-dim)] self-center ml-2">{filtered.length} tasks</span>
      </div>

      {/* Task list */}
      <div className="space-y-1.5">
        {filtered.map(task => {
          const overdue = task.status !== 'done' && task.dueDate <= new Date().toISOString().slice(0, 10);
          return (
            <div key={task.id} className={`flex items-center gap-3 px-4 py-3 rounded-lg border transition-all cursor-pointer group ${
              task.status === 'done' ? 'bg-[var(--bg-card)]/50 border-transparent opacity-60' : overdue ? 'bg-red-950/20 border-red-900/30' : 'bg-[var(--bg-card)] border-[var(--border)] hover:border-[var(--gold)]/30'
            }`}>
              {/* Checkbox */}
              <button onClick={(e) => { e.stopPropagation(); toggleStatus(task); }} className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                task.status === 'done' ? 'bg-green-600 border-green-600' : task.status === 'in_progress' ? 'border-[var(--gold)] bg-[var(--gold)]/20' : 'border-[var(--border)] hover:border-[var(--gold)]'
              }`}>
                {task.status === 'done' && <Icon d={Icons.check} size={12} className="text-white" />}
                {task.status === 'in_progress' && <div className="w-2 h-2 rounded-full bg-[var(--gold)]" />}
              </button>

              {/* Content */}
              <div className="flex-1 min-w-0" onClick={() => setEditingTask(task)}>
                <div className={`text-sm group-hover:text-[var(--gold)] transition-colors ${task.status === 'done' ? 'line-through text-[var(--text-dim)]' : ''}`}>{task.title}</div>
                <div className="flex items-center gap-2 mt-1">
                  <Badge text={task.priority} color={priorityColors[task.priority]} />
                  <Badge text={task.phase.replace('Phase ', 'P').split(':')[0]} color="navy" />
                  {task.tags.slice(0, 2).map(tag => <Badge key={tag} text={tag} color="gray" />)}
                </div>
              </div>

              {/* Due date */}
              <div className={`text-[11px] shrink-0 ${overdue ? 'text-red-400 font-semibold' : 'text-[var(--text-dim)]'}`}>
                {overdue ? 'OVERDUE · ' : ''}{task.dueDate}
              </div>

              {/* Delete */}
              <button onClick={(e) => { e.stopPropagation(); s(deleteTask(state, task.id)); }} className="opacity-0 group-hover:opacity-100 text-[var(--text-dim)] hover:text-red-400 transition-all"><Icon d={Icons.trash} size={13} /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
// CONTENT VIEW
// ═══════════════════════════════════════
function ContentView({ state, s }: { state: AppState; s: (n: AppState) => void }) {
  const typeIcons: Record<string, string> = { article: '📝', post: '💬', carousel: '🖼️', poll: '📊', comment_campaign: '💡' };

  return (
    <div className="animate-in">
      <div className="grid grid-cols-1 gap-3">
        {state.content.sort((a, b) => a.week - b.week).map(item => (
          <div key={item.id} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-xl px-5 py-4 flex items-start gap-4 hover:border-[var(--gold)]/30 transition-all">
            <div className="text-2xl mt-0.5">{typeIcons[item.type] || '📄'}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-mono text-[var(--text-dim)]">WEEK {item.week}</span>
                <Badge text={item.type.replace('_', ' ')} color="blue" />
                <Badge text={item.status} color={contentStatusColors[item.status]} />
              </div>
              <div className="text-sm font-medium mb-1">{item.title}</div>
              <div className="text-[11px] text-[var(--text-muted)]">{item.topic}</div>
              {item.url && <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-[var(--gold)] hover:underline mt-1 inline-block">{item.url}</a>}
            </div>
            <select
              value={item.status}
              onChange={e => s(updateContent(state, item.id, { status: e.target.value as ContentStatus, ...(e.target.value === 'published' ? { publishDate: new Date().toISOString().slice(0, 10) } : {}) }))}
              className="!w-auto !text-[11px] !py-1"
            >
              <option value="idea">Idea</option>
              <option value="drafting">Drafting</option>
              <option value="ready">Ready</option>
              <option value="published">Published</option>
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
// ACTIVITY VIEW
// ═══════════════════════════════════════
function ActivityView({ state, s, search }: { state: AppState; s: (n: AppState) => void; search: string }) {
  const filtered = state.activities.filter(a =>
    !search || a.description.toLowerCase().includes(search.toLowerCase())
  );

  const typeColors: Record<string, string> = { outreach: '#7b93b9', call: '#2C5F8A', meeting: '#1B2A4A', email: '#94a3b8', briefing: '#D4A843', proposal: '#b8912e', note: '#5c6070', content: '#9c27b0' };

  return (
    <div className="animate-in">
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-[var(--text-dim)] text-sm mb-2">No activity logged yet</div>
          <div className="text-[var(--text-dim)] text-xs">Click "Log Activity" to start tracking your outreach, calls, and meetings.</div>
        </div>
      ) : (
        <div className="space-y-1">
          {filtered.map(act => {
            const co = state.companies.find(c => c.id === act.companyId);
            const ct = state.contacts.find(c => c.id === act.contactId);
            return (
              <div key={act.id} className="flex items-start gap-4 px-4 py-3 bg-[var(--bg-card)] border border-[var(--border)] rounded-lg">
                <div className="w-2 h-2 rounded-full mt-2 shrink-0" style={{ backgroundColor: typeColors[act.type] || '#5c6070' }} />
                <div className="flex-1">
                  <div className="text-sm">{act.description}</div>
                  {act.outcome && <div className="text-[11px] text-[var(--text-muted)] mt-1 italic">Outcome: {act.outcome}</div>}
                  <div className="text-[10px] text-[var(--text-dim)] mt-1 flex items-center gap-2">
                    <span className="capitalize font-medium" style={{ color: typeColors[act.type] }}>{act.type}</span>
                    {co && <span>· {co.name}</span>}
                    {ct && <span>· {ct.name}</span>}
                    <span>· {act.date}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════
// ADD/EDIT COMPANY MODAL
// ═══════════════════════════════════════
function AddCompanyModal({ open, onClose, state, s, existing }: { open: boolean; onClose: () => void; state: AppState; s: (n: AppState) => void; existing: Company | null }) {
  const [name, setName] = useState('');
  const [tier, setTier] = useState<Tier>('1');
  const [sector, setSector] = useState('');
  const [painSignal, setPainSignal] = useState('');
  const [entryAngle, setEntryAngle] = useState('');
  const [stage, setStage] = useState<PipelineStage>('identified');
  const [estimatedValue, setEstimatedValue] = useState('20000');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (existing) {
      setName(existing.name); setTier(existing.tier); setSector(existing.sector);
      setPainSignal(existing.painSignal); setEntryAngle(existing.entryAngle);
      setStage(existing.stage); setEstimatedValue(String(existing.estimatedValue)); setNotes(existing.notes);
    } else {
      setName(''); setTier('1'); setSector(''); setPainSignal(''); setEntryAngle('');
      setStage('identified'); setEstimatedValue('20000'); setNotes('');
    }
  }, [existing, open]);

  const handleSave = () => {
    if (!name.trim()) return;
    if (existing) {
      s(updateCompany(state, existing.id, { name, tier, sector, painSignal, entryAngle, stage, estimatedValue: Number(estimatedValue), notes }));
    } else {
      s(addCompany(state, { name, tier, sector, painSignal, entryAngle, stage, estimatedValue: Number(estimatedValue), notes }));
    }
    onClose();
  };

  const handleDelete = () => {
    if (existing && confirm(`Delete ${existing.name} and all associated contacts?`)) {
      s(deleteCompany(state, existing.id));
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={existing ? `Edit: ${existing.name}` : 'Add Company'} wide>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Company Name"><input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Zilliant" /></Field>
        <Field label="Tier">
          <select value={tier} onChange={e => setTier(e.target.value as Tier)}>
            <option value="1">Tier 1 (Immediate)</option>
            <option value="2">Tier 2 (Strategic)</option>
            <option value="3_pe">PE Fund</option>
          </select>
        </Field>
        <Field label="Sector"><input value={sector} onChange={e => setSector(e.target.value)} placeholder="e.g. B2B Pricing Software" /></Field>
        <Field label="Pipeline Stage">
          <select value={stage} onChange={e => setStage(e.target.value as PipelineStage)}>
            {PIPELINE_STAGES.map(ps => <option key={ps.key} value={ps.key}>{ps.label}</option>)}
          </select>
        </Field>
        <div className="col-span-2"><Field label="Pain Signal"><textarea value={painSignal} onChange={e => setPainSignal(e.target.value)} rows={2} placeholder="What observable problem creates urgency?" /></Field></div>
        <div className="col-span-2"><Field label="Entry Angle"><textarea value={entryAngle} onChange={e => setEntryAngle(e.target.value)} rows={2} placeholder="How will you approach this company?" /></Field></div>
        <Field label="Estimated Value (EUR)"><input type="number" value={estimatedValue} onChange={e => setEstimatedValue(e.target.value)} /></Field>
        <Field label="Notes"><input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Target contacts, paths, etc." /></Field>
      </div>
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-[var(--border)]">
        {existing ? (
          <button onClick={handleDelete} className="text-xs text-red-400 hover:text-red-300 transition-colors">Delete Company</button>
        ) : <div />}
        <div className="flex gap-3">
          <button onClick={onClose} className="text-xs px-4 py-2 text-[var(--text-muted)] hover:text-white transition-colors">Cancel</button>
          <button onClick={handleSave} className="text-xs px-5 py-2 bg-[var(--gold)] text-black font-semibold rounded-lg hover:bg-yellow-500 transition-colors">{existing ? 'Save Changes' : 'Add Company'}</button>
        </div>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════
// ADD CONTACT MODAL
// ═══════════════════════════════════════
function AddContactModal({ open, onClose, state, s, preselectedCompany }: { open: boolean; onClose: () => void; state: AppState; s: (n: AppState) => void; preselectedCompany: string | null }) {
  const [companyId, setCompanyId] = useState('');
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [email, setEmail] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [role, setRole] = useState<ContactRole>('champion');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (preselectedCompany) setCompanyId(preselectedCompany);
    else if (state.companies.length > 0) setCompanyId(state.companies[0].id);
  }, [preselectedCompany, open, state.companies]);

  const handleSave = () => {
    if (!name.trim() || !companyId) return;
    s(addContact(state, { companyId, name, title, email, linkedin, role, notes, lastContactDate: '' }));
    setName(''); setTitle(''); setEmail(''); setLinkedin(''); setNotes('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="Add Contact">
      <Field label="Company">
        <select value={companyId} onChange={e => setCompanyId(e.target.value)}>
          {state.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Name"><input value={name} onChange={e => setName(e.target.value)} placeholder="Full name" /></Field>
        <Field label="Title"><input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. VP Customer Success" /></Field>
        <Field label="Email"><input type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>
        <Field label="LinkedIn URL"><input value={linkedin} onChange={e => setLinkedin(e.target.value)} placeholder="https://linkedin.com/in/..." /></Field>
      </div>
      <Field label="Role">
        <select value={role} onChange={e => setRole(e.target.value as ContactRole)}>
          <option value="champion">Champion</option>
          <option value="economic_buyer">Economic Buyer</option>
          <option value="influencer">Influencer</option>
          <option value="blocker">Blocker</option>
          <option value="other">Other</option>
        </select>
      </Field>
      <Field label="Notes"><textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} /></Field>
      <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-[var(--border)]">
        <button onClick={onClose} className="text-xs px-4 py-2 text-[var(--text-muted)]">Cancel</button>
        <button onClick={handleSave} className="text-xs px-5 py-2 bg-[var(--gold)] text-black font-semibold rounded-lg hover:bg-yellow-500 transition-colors">Add Contact</button>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════
// ADD/EDIT TASK MODAL
// ═══════════════════════════════════════
function AddTaskModal({ open, onClose, state, s, existing }: { open: boolean; onClose: () => void; state: AppState; s: (n: AppState) => void; existing: Task | null }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [phase, setPhase] = useState('Phase 1: Foundation');
  const [dueDate, setDueDate] = useState('');
  const [tags, setTags] = useState('');
  const [companyId, setCompanyId] = useState('');

  useEffect(() => {
    if (existing) {
      setTitle(existing.title); setDescription(existing.description); setStatus(existing.status);
      setPriority(existing.priority); setPhase(existing.phase); setDueDate(existing.dueDate);
      setTags(existing.tags.join(', ')); setCompanyId(existing.companyId || '');
    } else {
      setTitle(''); setDescription(''); setStatus('todo'); setPriority('medium');
      setPhase('Phase 1: Foundation'); setDueDate(new Date().toISOString().slice(0, 10)); setTags(''); setCompanyId('');
    }
  }, [existing, open]);

  const handleSave = () => {
    if (!title.trim()) return;
    const tagList = tags.split(',').map(t => t.trim()).filter(Boolean);
    if (existing) {
      s(updateTask(state, existing.id, { title, description, status, priority, phase, dueDate, tags: tagList, companyId: companyId || undefined, ...(status === 'done' && !existing.completedDate ? { completedDate: new Date().toISOString().slice(0, 10) } : {}) }));
    } else {
      s(addTask(state, { title, description, status, priority, phase, dueDate, tags: tagList, companyId: companyId || undefined }));
    }
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title={existing ? 'Edit Task' : 'Add Task'} wide>
      <Field label="Title"><input value={title} onChange={e => setTitle(e.target.value)} placeholder="What needs to be done?" /></Field>
      <Field label="Description"><textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="Details, context, dependencies..." /></Field>
      <div className="grid grid-cols-3 gap-4">
        <Field label="Status">
          <select value={status} onChange={e => setStatus(e.target.value as TaskStatus)}>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="done">Done</option>
            <option value="blocked">Blocked</option>
          </select>
        </Field>
        <Field label="Priority">
          <select value={priority} onChange={e => setPriority(e.target.value as TaskPriority)}>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </Field>
        <Field label="Due Date"><input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} /></Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Phase">
          <select value={phase} onChange={e => setPhase(e.target.value)}>
            <option value="Phase 1: Foundation">Phase 1: Foundation</option>
            <option value="Phase 2: Validation">Phase 2: Validation</option>
            <option value="Phase 3: Delivery">Phase 3: Delivery</option>
            <option value="Phase 4: Scale">Phase 4: Scale</option>
          </select>
        </Field>
        <Field label="Linked Company">
          <select value={companyId} onChange={e => setCompanyId(e.target.value)}>
            <option value="">None</option>
            {state.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Tags (comma-separated)"><input value={tags} onChange={e => setTags(e.target.value)} placeholder="e.g. legal, outreach, content" /></Field>
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-[var(--border)]">
        {existing ? (
          <button onClick={() => { s(deleteTask(state, existing.id)); onClose(); }} className="text-xs text-red-400 hover:text-red-300">Delete Task</button>
        ) : <div />}
        <div className="flex gap-3">
          <button onClick={onClose} className="text-xs px-4 py-2 text-[var(--text-muted)]">Cancel</button>
          <button onClick={handleSave} className="text-xs px-5 py-2 bg-[var(--gold)] text-black font-semibold rounded-lg hover:bg-yellow-500 transition-colors">{existing ? 'Save Changes' : 'Add Task'}</button>
        </div>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════
// ADD ACTIVITY MODAL
// ═══════════════════════════════════════
function AddActivityModal({ open, onClose, state, s }: { open: boolean; onClose: () => void; state: AppState; s: (n: AppState) => void }) {
  const [type, setType] = useState<Activity['type']>('outreach');
  const [description, setDescription] = useState('');
  const [companyId, setCompanyId] = useState('');
  const [contactId, setContactId] = useState('');
  const [outcome, setOutcome] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const companyContacts = companyId ? state.contacts.filter(c => c.companyId === companyId) : [];

  const handleSave = () => {
    if (!description.trim()) return;
    s(addActivity(state, { type, description, companyId: companyId || undefined, contactId: contactId || undefined, outcome: outcome || undefined, date }));
    setDescription(''); setOutcome('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="Log Activity">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Type">
          <select value={type} onChange={e => setType(e.target.value as Activity['type'])}>
            <option value="outreach">Outreach</option>
            <option value="call">Call</option>
            <option value="meeting">Meeting</option>
            <option value="email">Email</option>
            <option value="briefing">Executive Briefing</option>
            <option value="proposal">Proposal</option>
            <option value="note">Note</option>
            <option value="content">Content</option>
          </select>
        </Field>
        <Field label="Date"><input type="date" value={date} onChange={e => setDate(e.target.value)} /></Field>
      </div>
      <Field label="Company">
        <select value={companyId} onChange={e => { setCompanyId(e.target.value); setContactId(''); }}>
          <option value="">No company</option>
          {state.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </Field>
      {companyContacts.length > 0 && (
        <Field label="Contact">
          <select value={contactId} onChange={e => setContactId(e.target.value)}>
            <option value="">No specific contact</option>
            {companyContacts.map(c => <option key={c.id} value={c.id}>{c.name} - {c.title}</option>)}
          </select>
        </Field>
      )}
      <Field label="Description"><textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="What happened? What did you discuss?" /></Field>
      <Field label="Outcome (optional)"><input value={outcome} onChange={e => setOutcome(e.target.value)} placeholder="e.g. Agreed to schedule executive briefing" /></Field>
      <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-[var(--border)]">
        <button onClick={onClose} className="text-xs px-4 py-2 text-[var(--text-muted)]">Cancel</button>
        <button onClick={handleSave} className="text-xs px-5 py-2 bg-[var(--gold)] text-black font-semibold rounded-lg hover:bg-yellow-500 transition-colors">Log Activity</button>
      </div>
    </Modal>
  );
}
